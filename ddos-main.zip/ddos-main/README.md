# ndbiaw
Một tập lệnh Python để DDOS một trang web bằng phương pháp HTTP Flood, một trang web bình thường chỉ cần 5s để sập hoàn toàn!
# Cách Dùng:
Tập lệnh này có thể hoạt động cả trên Windows lẫn Android (Termux), dưới đây là hướng dẫn:
```
pip install requirements.txt
python ndbiaw.py
```
# Important!!!
This script is for educational purposes only. I am not responsible for the damage you cause while using this script!
```
Based on Pummel by HC 133
```
